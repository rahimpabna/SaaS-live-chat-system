import mongoose from 'mongoose';

const ConversationSchema = new mongoose.Schema({
  visitorId: { type: mongoose.Schema.Types.ObjectId, ref: 'Visitor', required: true },
  agentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  departmentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
  status: { type: String, enum: ['open', 'pending', 'resolved', 'spam'], default: 'open' },
  tags: [{ type: String }],
  notes: { type: String },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

export const Conversation = mongoose.models.Conversation || mongoose.model('Conversation', ConversationSchema);
