import mongoose from 'mongoose';

const MessageSchema = new mongoose.Schema({
  conversationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Conversation', required: true },
  senderType: { type: String, enum: ['visitor', 'agent', 'bot'], required: true },
  senderId: { type: String, required: true }, // can be visitor ID or agent user ID
  content: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  status: { type: String, enum: ['sent', 'delivered', 'seen'], default: 'sent' }
});

export const Message = mongoose.models.Message || mongoose.model('Message', MessageSchema);
