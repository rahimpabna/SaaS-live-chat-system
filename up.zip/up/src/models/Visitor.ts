import mongoose from 'mongoose';

const VisitorSchema = new mongoose.Schema({
  sessionId: { type: String, required: true, unique: true },
  name: { type: String },
  email: { type: String },
  phone: { type: String },
  ip: { type: String },
  country: { type: String },
  city: { type: String },
  device: { type: String },
  browser: { type: String },
  os: { type: String },
  referrer: { type: String },
  currentUrl: { type: String },
  journeyLogs: [{
    url: String,
    title: String,
    timestamp: { type: Date, default: Date.now }
  }],
  createdAt: { type: Date, default: Date.now }
});

export const Visitor = mongoose.models.Visitor || mongoose.model('Visitor', VisitorSchema);
