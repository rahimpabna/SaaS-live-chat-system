import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 465,
  secure: true,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export const sendEmail = async (to: string, subject: string, htmlContent: string) => {
  const info = await transporter.sendMail({
    from: process.env.EMAIL_FROM || '"Live Chat Support" <support@textbii.com>',
    to,
    subject,
    html: htmlContent,
  });
  return info;
};

// ==========================================
// BEAUTIFUL EMAIL TEMPLATES
// ==========================================

const baseTemplate = (title: string, content: string, footer: string = 'textbii.com Support Team') => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background-color: #f3f4f6; padding: 40px 0; margin: 0; }
    .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
    .header { background-color: #2563eb; padding: 30px; text-align: center; color: #ffffff; }
    .header h1 { margin: 0; font-size: 24px; font-weight: 600; }
    .content { padding: 40px 30px; color: #374151; line-height: 1.6; font-size: 16px; }
    .button { display: inline-block; background-color: #2563eb; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600; margin-top: 20px; }
    .footer { background-color: #f9fafb; padding: 20px 30px; text-align: center; color: #6b7280; font-size: 14px; border-top: 1px solid #e5e7eb; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${title}</h1>
    </div>
    <div class="content">
      ${content}
    </div>
    <div class="footer">
      &copy; ${new Date().getFullYear()} ${footer}. All rights reserved.<br>
      <a href="https://textbii.com" style="color: #2563eb; text-decoration: none;">textbii.com</a>
    </div>
  </div>
</body>
</html>
`;

export const getPasswordResetEmail = (resetLink: string) => {
  const content = `
    <h2>Password Reset Request</h2>
    <p>We received a request to reset the password for your account.</p>
    <p>If you didn't make this request, you can safely ignore this email.</p>
    <div style="text-align: center;">
      <a href="${resetLink}" class="button">Reset Password</a>
    </div>
    <p style="margin-top: 30px; font-size: 14px; color: #6b7280;">Or copy and paste this link into your browser:<br>
    <a href="${resetLink}" style="color: #2563eb; word-break: break-all;">${resetLink}</a></p>
  `;
  return baseTemplate('Reset Your Password', content);
};

export const getWelcomeEmail = (name: string, loginLink: string) => {
  const content = `
    <h2>Welcome to Textbii, ${name}!</h2>
    <p>We're thrilled to have you on board. Your account has been successfully created.</p>
    <p>You can now log in to the dashboard and start managing your live chats.</p>
    <div style="text-align: center;">
      <a href="${loginLink}" class="button">Log In to Dashboard</a>
    </div>
  `;
  return baseTemplate('Welcome to Textbii', content);
};

export const getChatTranscriptEmail = (customerName: string, transcriptHtml: string) => {
  const content = `
    <h2>Your Chat Transcript</h2>
    <p>Hi ${customerName},</p>
    <p>Thank you for chatting with us today. Here is a copy of your conversation for your records:</p>
    <div style="background-color: #f9fafb; padding: 15px; border-radius: 6px; border: 1px solid #e5e7eb; margin: 20px 0;">
      ${transcriptHtml}
    </div>
    <p>If you have any further questions, simply reply to this email or visit our website.</p>
  `;
  return baseTemplate('Textbii Support Chat Transcript', content);
};

export const getAgentNotificationEmail = (agentName: string, ticketSubject: string, link: string) => {
  const content = `
    <h2>New Assigned Chat</h2>
    <p>Hi ${agentName},</p>
    <p>A new chat has been assigned to you or your department:</p>
    <p><strong>Subject:</strong> ${ticketSubject}</p>
    <div style="text-align: center;">
      <a href="${link}" class="button">View Chat</a>
    </div>
  `;
  return baseTemplate('New Chat Assignment', content);
};
