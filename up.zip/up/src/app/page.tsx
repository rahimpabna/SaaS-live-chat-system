import Link from "next/link"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24 bg-slate-50">
      <div className="max-w-3xl w-full space-y-8 text-center">
        <h1 className="text-5xl font-extrabold tracking-tight text-slate-900">
          Live Chat SaaS Platform
        </h1>
        <p className="text-xl text-slate-600">
          AI-powered customer support system and helpdesk.
        </p>
        
        <div className="flex gap-4 justify-center pt-8">
          <Link href="/admin" className="px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition">
            Admin Dashboard
          </Link>
          <Link href="/agent" className="px-8 py-4 bg-white text-slate-900 shadow-sm border border-slate-200 rounded-lg font-semibold hover:bg-slate-50 transition">
            Agent Panel
          </Link>
        </div>
      </div>
    </main>
  )
}
