const Client = require('ssh2-sftp-client');
const { Client: SSHClient } = require('ssh2');
const path = require('path');

const config = {
  host: '91.134.140.50',
  port: 22,
  username: 'ubuntu',
  password: 'Z7gZASZZBRqt'
};

const sftp = new Client();
const localDir = process.cwd();
const remoteDir = '/home/ubuntu/livechat';

async function deploy() {
  try {
    console.log('Connecting to SFTP...');
    await sftp.connect(config);
    console.log('Connected! Uploading files (this might take a minute)...');
    
    // Ignore node_modules, .git, .next, etc.
    const filter = (localPath) => {
      const p = localPath.replace(/\\/g, '/');
      return !p.includes('/node_modules') && 
             !p.includes('/.git') && 
             !p.includes('/.next') &&
             !p.endsWith('.zip');
    };

    await sftp.uploadDir(localDir, remoteDir, { filter });
    console.log('Upload completed successfully!');
    await sftp.end();

    console.log('Connecting via SSH to run installation scripts...');
    const conn = new SSHClient();
    conn.on('ready', () => {
      console.log('SSH Client ready. Starting installation...');
      
      const pass = 'Z7gZASZZBRqt';
      const sudoCmd = (cmd) => `echo "${pass}" | sudo -S bash -c "${cmd}"`;
      
      // Combine all commands into one script to run on remote
      const remoteScript = `
        set -e
        echo "Updating system..."
        ${sudoCmd('apt-get update && apt-get install -y dos2unix')}
        
        echo "Setting up directories..."
        ${sudoCmd('mkdir -p /var/www/livechat')}
        ${sudoCmd('cp -r /home/ubuntu/livechat/* /var/www/livechat/')}
        ${sudoCmd('cp /home/ubuntu/livechat/.env.example /var/www/livechat/.env')}
        
        echo "Fixing permissions and line endings..."
        ${sudoCmd('cd /var/www/livechat && dos2unix install.sh mail-setup.sh || true')}
        ${sudoCmd('cd /var/www/livechat && chmod +x install.sh mail-setup.sh update.sh backup.sh')}
        
        echo "Running main installation..."
        ${sudoCmd('cd /var/www/livechat && ./install.sh')}
        
        echo "Running mail server installation..."
        ${sudoCmd('cd /var/www/livechat && ./mail-setup.sh')}
        
        echo "Seeding database..."
        ${sudoCmd('cd /var/www/livechat && npm run seed')}
        
        echo "DEPLOYMENT FINISHED!"
      `;

      conn.exec(remoteScript, { pty: true }, (err, stream) => {
        if (err) throw err;
        stream.on('close', (code, signal) => {
          console.log('Installation process closed with code ' + code);
          conn.end();
        }).on('data', (data) => {
          process.stdout.write(data.toString('utf-8'));
        }).stderr.on('data', (data) => {
          process.stderr.write(data.toString('utf-8'));
        });
      });
    }).connect(config);

  } catch (err) {
    console.error('Error during deployment:', err);
  }
}

deploy();
