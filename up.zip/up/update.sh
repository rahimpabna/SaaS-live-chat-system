#!/bin/bash
set -e

APP_DIR="/var/www/livechat"

echo "Pulling latest changes..."
cd $APP_DIR
git pull origin main

echo "Installing dependencies..."
npm install

echo "Building Next.js application..."
npm run build

echo "Restarting PM2 process..."
pm2 reload livechat

echo "Update complete!"
